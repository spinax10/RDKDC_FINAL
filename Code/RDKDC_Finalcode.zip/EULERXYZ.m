function Q = EULERXYZ(x)
    X = ROTX(x(1));
    Y = ROTY(x(2));
    Z = ROTZ(x(3));
    Q = X*Y*Z;
end