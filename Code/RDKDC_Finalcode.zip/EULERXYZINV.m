function Q = EULERXYZINV(x)
%note; MATLab has atan2 use (y,x) whereas I used atan2(x,y) in my homework
    %angle1 = atan2(sqrt((x(1,1))^2+(x(1,2))^2),x(1,3))
    %[pi/2;pi/6;pi/4]
    %order goes xphi, ytheta, zpsi
    if(x(1,3) == 1)
        %throw error vs print a display and return zero vector.
        %I toggle off the error throw when running the script in full.
        disp("Bad input! Results in undefined atan2! Returning zero vector!")
        Q = [0;0;0];
        %msg = "Matrix has 90 degree y-rotation, creating a divide by zero error in inverse calculation. Retry with new angles.";
        %error(msg)

    else

        phi = atan2(-x(2,3)/(sqrt(1-(x(1,3))^2)),x(3,3)/(sqrt(1-(x(1,3))^2)));
        theta = atan2(x(1,3),sqrt((x(1,1))^2+(x(1,2))^2));
        psi = atan2(-x(1,2)/(sqrt(1-(x(1,3))^2)),x(1,1)/(sqrt(1-(x(1,3))^2)));
        %angle1 = atan2(x(1,3))
        Q = [phi;theta;psi];
    end
       %Q will be angles calculated with atan2 as derived in homework 3, should be straightforward
    %find out which rotation matrices are ill-defined for inverse. probably going to be where there are zero's in the r positions?
    %ned to show that given a vector of angles that working both functions with one another doesn't always net the equality
    %show that a given rotation matrix when inserted into inverse then full is itself.
end