function error = ur5Error(ur5,actual, expected)
    %rotational error
    error = [0;0];
    traceterm = actual(1:3,1:3)-expected(1:3,1:3);
    error(1) = sqrt(trace(traceterm*transpose(traceterm)));
    error(2) = norm(actual(1:3,4) - expected(1:3,4));
    
end