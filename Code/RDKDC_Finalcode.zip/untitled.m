test1 = eye(3);
for i = 1:90
    test2 = test1*