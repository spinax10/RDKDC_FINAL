function done = ur5InverseControlwithsafety(ur5, start_frame, end_frame, percentage, threshold)
    %first setup the start and end frames
    %w = waitforbuttonpress;
    %add marker transformation to start and end frames
    marker_frame = [1,0,0,45/1000;0,1,0,0;0,0,1,120/1000;0,0,0,1];
    start_frame = start_frame*marker_frame;
    end_frame = end_frame*marker_frame;
    %convert end_frame vector to start_frame reference
    translationframe = inv(start_frame)*end_frame;
    
    %undo translation of marker for coordinate calculations
    start_frame = start_frame*inv(marker_frame);
    end_frame = end_frame*inv(marker_frame);
    overdistance1 = translationframe(2,4)*percentage;
    downdistance = translationframe(1,4);
    overdistance2 = translationframe(2,4)*(1-percentage);
    %start_frame(1:3,1:3) = end_frame(1:3,1:3);

    % start_joints = ur5InvKin(start_frame);
    % end_joints = ur5InvKin(end_frame);
    % des_joints = [start_joints(1:5);end_joints(6)];
    % start_frame2 = ur5FwdKin(des_joints);
    % rot_theta = ur5InvKin(start_frame2);
    % joint_rot = determineangle(rot_theta,ur5);
    % ur5.move_joints(rot_theta(1:6,joint_rot),pause(3));
    % 


    %quick safety check
    % if(end_frame(3,4)-start_frame(3,4) < threshold)
    %    disp("Goal frame is significantly lower than start frame. Potential collision averted, retry goal frame")
    %    done = 0;
    %    return;
    % end
    % overdistance1 = 50/1000;
    % downdistance = 75/1000;
    % overdistance2 = 100/1000;
    %stepsizes = [overdistance1, downdistance, overdistance2]*1000;
    stepsizes = [30,30,30];

    %setup explicit rotations
    
    
    %timings = [line_time/stepsizes(1),line_time/stepsizes(2), line_time/stepsizes(3)];
    timings = [0.2,0.2,0.2]*20;
    %new_transform_over1 = start_frame;
    for i = 1:stepsizes(1)
    new_transform_over1 = start_frame*[1,0,0,0;0,1,0,overdistance1*i/stepsizes(1);0,0,1,0;0,0,0,1];
    
    %theta calculation to move ur5 over distance/mnt/nfshomes/tsingh21/Downloads/fin/myfilesthirdversion
    thetasolutionsover1 = ur5InvKin(new_transform_over1);

    jointiteration = determineangle(thetasolutionsover1,ur5)
    
    %solver for best angle combination here
    
    ur5.move_joints(thetasolutionsover1(1:6,jointiteration),timings(1));
    
    disp("Moving first position")
    pause(timings(1));
    
    Frame_B = tf_frame("base_link", "frame1_" + i, new_transform_over1);
    end
    %new_transform_down = new_transform_over1
    for i = 1:stepsizes(2)
    new_transform_down = new_transform_over1 * [1,0,0,downdistance*i/stepsizes(2);0,1,0,0;0,0,1,0;0,0,0,1];
    %new_transform_down(1:3,1:3) = new_transform_down(1:3,1:3)*rotation_frame;
    thetasolutionsdown = ur5InvKin(new_transform_down);
    jointiteration = determineangle(thetasolutionsdown,ur5);

    ur5.move_joints(thetasolutionsdown(1:6,jointiteration),timings(2));
    
    disp("Moving second position")
    pause(timings(2));
    
    Frame_C = tf_frame("base_link", "frame2_"+i, new_transform_down);
    end
    %and repeat again for the second over
    new_transform_over2 = new_transform_down;
    down_angles = EULERXYZINV(new_transform_over2);
        %angle difference calculation
    start_angles = EULERXYZINV(new_transform_over2);
    end_angles = EULERXYZINV(end_frame);
    %difference_angle = (end_angles-start_angles)/sum(stepsizes);
    for i = 1:stepsizes(3)
    
    new_transform_over2 = new_transform_down * [1,0,0,0;0,1,0,overdistance2*i/stepsizes(3);0,0,1,0;0,0,0,1];
    %new_transform_over2(1:3,1:3) = new_transform_over2(1:3,1:3)*rotation_frame;
    %new_transform_over2(1:3,1:3) = ROTX(down_angles(1))*ROTX(difference_angle(1)*(stepsizes(1)/i))*ROTY(down_angles(2))*ROTY(difference_angle(2)*(stepsizes(1)/i))*ROTZ(down_angles(3))*ROTZ(difference_angle(3)*(stepsizes(1)/i));
    thetasolutionsover2 = ur5InvKin(new_transform_over2);
    jointiteration = determineangle(thetasolutionsover2,ur5);
    ur5.move_joints(thetasolutionsover2(1:6,jointiteration),timings(3));
    
  
    disp("Moving third position")
    pause(timings(3));
    Frame_D = tf_frame("base_link", "frame3_"+i, new_transform_over2);
    end
    final_frame = new_transform_over2*[end_frame(1:3,1:3),[0;0;0];0,0,0,1];
    final_joints = ur5InvKin(final_frame);
    ur5.move_joints()
    if(true)
        done = new_transform_over2;
    else
        done = 0;
    end
end