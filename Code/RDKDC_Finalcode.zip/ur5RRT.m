%This function is the Resolved-Rate controller using transpose of Body
%Jacobian for UR5 robot.
%Inputs: gdesired (desired frame of tool0 w.r.t base_link)
%K (controller gain)
%ur5 (an object of ur5.interface())
%Outputs: dso3 (rotational error)
%dr3 (positional error)
function [dso3,dr3] = ur5RRT(gdesired,K,ur5)
%q_f = [-1.3;1.2;0.5;pi/2;pi/4;pi/2];
%q_f2 = [pi/2;-pi/2;0;0.1;0.1;0.1];
pause(0.5);
T_step = 0.05; %define step size
q_k = ur5.get_current_joints;
gst_star = gdesired;
gst = ur5FwdKin(q_k);
e = inv(gst_star)*gst;
xi_k = getXi(e);
v_norm = norm(xi_k(1:3));
w_norm = norm(xi_k(4:end));
v_limit = 0.005; %while loop exit limit for v
w_limit = 15*pi/180; %while loop exit limit for w
n = 0;
while v_norm>v_limit || w_norm>w_limit
y = 0;
det_jacob = det(ur5BodyJacobian(q_k)); %check for singularity
if norm(det_jacob)<10^-9
fprintf("Close to singularity");
x = -1;
break;
end
Jb = ur5BodyJacobian(q_k);
error_mag1 = norm(xi_k);
q_k1 = q_k - K*(T_step)*((Jb)')*xi_k;
gst = ur5FwdKin(q_k1);
e = inv(gst_star)*gst;
xi_k = getXi(e);
v_norm = norm(xi_k(1:3));
w_norm = norm(xi_k(4:end));
q_last = q_k1;
q_k = q_k1;
%check for joint angle limits (-pi to pi)
for i=1:6
    c = q_k(i);
    if c>pi
        q_k(i) = -pi + mod(c,pi);
        y = 1;
    end
    if c<-pi
        q_k(i) = pi - mod(c*-1,pi);
        y = 1;
    end
end
%Performs joint checks and changes the value of the angles which
%violates joint limits. Thus function is written at the end of the
%function below.
[q_f,l] = joint_check(q_k);
q_k = q_f;
if l==1
ur5.move_joints(q_k,12);
pause(15);
end
gst = ur5FwdKin(q_k);
%Ground collision check of the end effector
if gst(3,4)<0.12
if q_k(2)>-pi/2
q_k(2)=q_k(2)-0.1; %We check on which side the joint 2 is and then rotate it
%accordingly to lift it up a bit.
end
if q_k(2)<-pi/2
q_k(2)=q_k(2)+0.1;
end
end
if y == 1 && n~=0
ur5.move_joints(q_k,12);
pause(13);
else
error_mag = norm(xi_k(1:3));
m_t = error_mag*50;
ur5.move_joints(q_k,m_t);
end
n=1;
end
%Find the desired and actual transformation matrices of gripper_pick w.r.t
%tool0
gripper_d = find_gripper_for_tool0(gst_star,ur5);
gripper_act = find_gripper_for_tool0(gst,ur5);
R = gripper_act(1:3,1:3);
r = gripper_act(1:3,4);
Rd = gripper_d(1:3,1:3);
rd = gripper_d(1:3,4);
dso3 = sqrt(trace((R-Rd)*(R-Rd)'));
dr3 = norm(r-rd);
end
function [q,l] = joint_check(q_o)
%We check the joint 2 to see if it hits the ground. In case it hits
%the ground, rather than changing the angles of just joint2 and
%joint 3 and possibly passing through singularity, we rotate the
%base i.e the joint 1 by 180 degrees. And as the joint 2 is near 0,
%we subtract p/2 to lift it up. This sends the robot to an
%alternate config from where it can go to the desired target.
l=0;
for j=2:5
j_angle = q_o(j);
if j==2
if j_angle>-0.15 || j_angle<-2.98
if q_o(1)<0
q_o(1) = q_o(1)+pi;
if j_angle<-2.98
q_o(j) = q_o(j)+pi/3;
else
q_o(j) = q_o(j)-pi/3;
end
else
q_o(1)= q_o(1)-pi;
if j_angle<-2.98
q_o(j) = q_o(j)+pi/3;
else
q_o(j) = q_o(j)-pi/3;
end
end
l=1;
end
end
end
q = q_o;
end