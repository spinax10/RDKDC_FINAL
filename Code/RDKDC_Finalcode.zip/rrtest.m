% ur5 = ur5_interface();
% %pause(5);
% ur5.swtich_to_ros_control();
% % ur5.move_joints(ur5.home(),30);
% %pause(5);
ur5 = ur5_interface();
ur5.swtich_to_ros_control();
ur5.move_joints(ur5.home(),20);
pause(20);
disp("Move Robot to end position.")
ur5.swtich_to_pendant_control();
w1 = waitforbuttonpress();
endangles = ur5.get_current_joints();
endtransform = ur5FwdKin(endangles);
end_frame = endtransform;
disp("Move robot to start position.")
w2 = waitforbuttonpress();
ur5.swtich_to_ros_control();
startangles = ur5.get_current_joints();
starttransform = ur5FwdKin(startangles);
start_frame = starttransform;
% newval = resolved_rate(ur5, start_frame, 50/1000,75/1000,100/1000,4,1);
Pa = start_frame(1:3,4) + [0, (end_frame(2,4) - start_frame(2,4))/3,0]';
Pb = Pa + [end_frame(1,4) - start_frame(1,4),0,0]';
A1 = EULERXYZINV(start_frame(1:3,1:3));
A2 = EULERXYZINV(end_frame(1:3,1:3));
Aa = A1 + (A2 - A1)/3;
Ab = Aa + (A2 - A1)/3;
Ea = [
  EULERXYZ(Aa),Pa;  
  0,0,0,1
];
Eb = [
  EULERXYZ(Ab),Pb;
  0,0,0,1
];
ur5RRcontrol(Ea, 1, ur5, 0.4);
ur5RRcontrol(Eb, 1, ur5, 0.4);
ur5RRcontrol(end_frame, 1, ur5, 0.4);
% for i = 1:1
%     new_transform_over1 = currentframe*[1,0,0,0;0,1,0,dist;0,0,1,0;0,0,0,1];
%     disp(i);
%     disp(norm(new_transform_over1(1:3,4)-currentframe(1:3,4)))
%     ur5RRcontrol(new_transform_over1, 0.5, ur5, 0.2);
%     currentframe = new_transform_over1;
% end
% g = start_frame * [
%     1,0,0,0;
%     0,1,0,-.2;
%     0,0,1,0;
%     0,0,0,1
% ];
% disp("currentframe");
% disp(currentframe);
%
% k = 0.3; % for resolved rate
% % k = 1; % for jacobian transpose
% % ur5RRcontrol(g, k, ur5, 0.3);
%
% currentangles = ur5.get_current_joints();
% finaltransform = ur5FwdKin(currentangles);
%
% disp("final frame");
% disp(finaltransform);