function safetyval = ur5MarkerSafetyCheck(start_frame,end_frame,markermeasures,threshold)
start_frame_safe = start_frame*[1,0,0,-markermeasures(1)/1000;0,1,0,0;0,0,1,markermeasures(2)/1000;0,0,0,1];
end_frame_safe = end_frame*[1,0,0,-markermeasures(1)/1000;0,1,0,0;0,0,1,markermeasures(2)/1000;0,0,0,1];

if((start_frame_safe(3,4)) < threshold || (end_frame_safe(3,4) < threshold))
%if((start_frame_safe(1,4) < threshold) || (start_frame_safe(2,4) < threshold) || (end_frame_safe(1,4) < threshold) || (end_frame_safe(2,4) < threshold))
       disp("Marker tip overreaching into surface. Please re-setup transformations, or lower threshold.")
       safetyval = 0;
else
    disp("Safety check satisfied. Robot will proceed with drawing task.")
    safetyval = 1;
end 

end