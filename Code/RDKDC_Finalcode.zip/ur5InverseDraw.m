function complete = ur5InverseDraw(ur5, start, final, steps, percentage, timestep,mainorbats, pointlist, scalar)
    %extract transformation between points
    transform = start\final;
    %extract euler angles from transform
    t_angles = EULERXYZINV(transform(1:3,1:3));
    %extract position from transform
    position = transform(1:3,4);
    %break apart position
    position1 = [position(1)*percentage;0;0];
    position2 = [0;position(2);0];
    position3 = [position(1)*(1-percentage);0;0];

if(mainorbats == "main")
    %using steps in each loop
    disp("Entering loop 1")
    for i = 1:steps
        %define step angles
        rotation = EULERXYZ(t_angles*(i/(3*steps)));
        %define position step
        pos = position1*(i/(steps));
        %create matrix to transform with
        stepform = rotation;
        stepform(4,4) = 1;
        stepform(1:3,4) = pos;
        %apply transformation
        current_transform = start*stepform;
        newframe = tf_frame("base_link", "transform1_" + i, current_transform);
        %find angles from current_transform;
        angleset = ur5InvKin(current_transform);
        %find best angle set
        bestangleselection = determineangle(angleset,ur5);
        %send angles to UR5
        ur5.move_joints(angleset(1:6,bestangleselection), timestep);
        pause(timestep);

    end
    firsttransform = current_transform;
    %repeat for position 2, adjusting start for current_transform and
    %multiplying i by 2
disp("Entering loop 2")
 for i = 1:steps
        %define step angles
        rotation = EULERXYZ(t_angles*((steps+i)/(3*steps)));
        %define position step
        pos = position2*(i/steps);
        %create matrix to transform with
        stepform = rotation;
        stepform(4,4) = 1;
        stepform(1:3,4) = pos;
        %apply transformation
        current_transform = firsttransform*stepform;
        %try this?
        current_transform(1:3,1:3) = start(1:3,1:3)*rotation;
        %find angles from current_transform;
        newframe = tf_frame("base_link", "transform2_" + i, current_transform);
        angleset = ur5InvKin(current_transform);
        %find best angle set
        bestangleselection = determineangle(angleset,ur5);
        %send angles to UR5
        ur5.move_joints(angleset(1:6,bestangleselection), timestep);
        pause(timestep);
 end
secondtransform = current_transform;
 %and for position3
disp("Entering loop 3")

 for i = 1:steps
        %define step angles
        rotation = EULERXYZ(t_angles*(((2*steps)+i))/(3*steps));
        %define position step
        pos = position3*(i/(steps));
        %create matrix to transform with
        stepform = rotation;
        stepform(4,4) = 1;
        stepform(1:3,4) = pos;
        %apply transformation
        current_transform = secondtransform*stepform;
        %try this?
        current_transform(1:3,1:3) = start(1:3,1:3)*rotation;
        %find angles from current_transform;
        newframe = tf_frame("base_link", "transform3_" + i, current_transform);
        angleset = ur5InvKin(current_transform);
        %find best angle set
        bestangleselection = determineangle(angleset,ur5);
        %send angles to UR5
        ur5.move_joints(angleset(1:6,bestangleselection), timestep);
        pause(timestep);

 end
 complete = current_transform;

else(mainorbats == "bats")
    %so we need to process the different data points. I will assume the
    %first point is always the starting point.
    variable = size(pointlist);
    loopvar = variable(1);
    start_point = [pointlist(1,1),pointlist(1,2)];
    for i = 1:loopvar
        disp("Iteration " + i)
        
        %define point transformation
        point_transform = [pointlist(i,1)-start_point(1);pointlist(i,2)-start_point(2)];
        %correction for orientation
        correction = start(1:3,1:3)\ROTZ(pi/2);
        point_transform = correction(1:2,1:2)*point_transform;
        %add this new transform to the start_frame matrix, with
        %postprocessing and scaling value
        next_frame = start;
        next_frame(1,4) = start(1,4) + point_transform(1)*scalar/1000;
        next_frame(2,4) = start(2,4) + point_transform(2)*scalar/1000;
      
        
        %run inverse kinematics
        
        FRAME = tf_frame("base_link", "frame_" + i, next_frame);
        if(i ~= 1)
        next_point_angles = ur5InvKin(next_frame);
        %find best set
        best_selection = determineangle(next_point_angles,ur5);
        %move ur5
        ur5.move_joints(next_point_angles(1:6,best_selection), timestep);
        pause(timestep);
        end
        if(i == 1)
            saved_frame = next_frame;
        end

    end
    %finish drawing by going back to beginning
    final_angles = ur5InvKin(saved_frame);
    best_selection = determineangle(final_angles, ur5);
    ur5.move_joints(final_angles(1:6, best_selection), timestep);
    pause(timestep);
    complete = eye(4);
end
end