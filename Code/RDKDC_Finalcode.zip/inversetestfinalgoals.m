ur5 = ur5_interface();
ur5.swtich_to_ros_control();
ur5.move_joints(ur5.home(),20);
pause(20);
disp("Move Robot to end position.")
ur5.swtich_to_pendant_control();
w1 = waitforbuttonpress();
endangles = ur5.get_current_joints();
endtransform = ur5FwdKin(endangles);
end_frame = endtransform;
disp("Move robot to start position.")
w2 = waitforbuttonpress();
ur5.swtich_to_ros_control();
startangles = ur5.get_current_joints();
starttransform = ur5FwdKin(startangles);
start_frame = starttransform;
disp("Beginning run")
start_frame1 = tf_frame("base_link", "start", start_frame);
end_frame1 = tf_frame("base_link", "end", end_frame); 
%aaaaa =  movve(ur5, start_frame, end_frame);

newval = ur5InverseControlwithsafety(ur5, start_frame, end_frame,0.8,0);



% testtransform = [[0.717285854290293	-0.695875000880764	0.0354821981314850	0.394604621900609],
% [-0.693872935365060	-0.708721447573162	0.127492193163647	0.565536695478913],
% [-0.0635716352072200	-0.116068483659428	-0.991204698484668	0.340696303390598],
% [0	0	0	1]];
%start_frame = [1,0,0,200/1000;0,1,0,200/1000;0,0,1,200/1000;0,0,0,1];

% ur5.move_joints(ur5InvKin(start_frame), 30);
% pause(30);
% newval = ur5InverseControlextra(ur5, start_frame, 50/1000,75/1000,100/1000,4);

% g = [
%     [ 0.8375,   -0.5282, -0.1399, 0.2857];
%     [ -0.4801,   -0.8336,    0.2731,    0.6934];
%     [ -0.2609,   -0.1615   -0.9518    0.1225];
%     [  0, 0, 0, 1 ]
% ];
% 
% ur5RRcontrol(g, 0.2, ur5);

% newval = resolved_rate(ur5, start_frame, 50/1000,75/1000,100/1000,4,1);