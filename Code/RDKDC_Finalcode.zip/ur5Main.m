ur5 = ur5_interface();
disp("Welcome! Please select which mode you would like to use for the UR5 drawing demonstration.")
disp("1: Inverse Kinematics")
disp("2: Resolved Rate Control")
disp("3: Jacobian Transpose Control")
disp("4: Shape Drawing")
value = input("Input your desired control scheme now: ");
if(value == 1)
    disp("You have selected Inverse kinematic control.")
elseif(value == 2)
    disp("You have selected Resolved Rate control.")
elseif(value == 3) 
    disp("You have selected Jacobian Transpose control.")
elseif(value == 4)
    disp("You have selected Shape Drawing functionality.")
else
    disp("Invalid entry. Please retry until a correct value has been selected")
    while(true)
        value = input("Input proper control scheme value now: ");
        if(value == 1 || value == 2 || value == 3 || value == 4 )
            break;
        end
    end
end

%Setup first pose of ur5
disp("Please move the robot to the end position of the desired drawing, and")
disp("then click on the figure to continue.")
ur5.swtich_to_pendant_control();
w1 = waitforbuttonpress();
end_joints = ur5.get_current_joints();
end_frame = ur5FwdKin(end_joints);
disp("Now move the robot to the starting position of the drawing.")
w2 = waitforbuttonpress();
start_joints = ur5.get_current_joints();
start_frame = ur5FwdKin(start_joints);
ur5.swtich_to_ros_control();
disp("Great! Running a quick safety check to ensure the marker will not go through the table...")
safetyval = ur5MarkerSafetyCheck(start_frame,end_frame,[40,140],0.05);
if(safetyval == 1)
    disp("Safety check complete! Thanks for waiting.")
    disp("Beginning drawing")
    switch value
        case 1
            ur5InverseDraw(ur5, start_frame, end_frame, 60, 0.66, 0.1, "main", [0], 0);
        case 2

            %ur5 RR control goes here

            Pa = start_frame(1:3,4) + [0, ((end_frame(2,4) - start_frame(2,4))*(2/3)),0]';
            Pb = Pa + [end_frame(1,4) - start_frame(1,4),0,0]';
            A1 = EULERXYZINV(start_frame(1:3,1:3));
            A2 = EULERXYZINV(end_frame(1:3,1:3));
            Aa = A1 + (A2 - A1)/3;
            Ab = Aa + (A2 - A1)/3;
            Ea = [
              EULERXYZ(Aa),Pa;  
              0,0,0,1
            ];
            Eb = [
              EULERXYZ(Ab),Pb;
              0,0,0,1
            ];
            ur5RRcontrol(Ea, 1, ur5, 0.4);
            ur5RRcontrol(Eb, 1, ur5, 0.4);
            ur5RRcontrol(end_frame, 1, ur5, 0.4);

        case 3

            %ur5 JT control goes here

            P_diff = [ end_frame(1,4) - start_frame(1,4); end_frame(2,4) - start_frame(2,4); 0];

            A1 = EULERXYZINV(start_frame(1:3,1:3));
            A2 = EULERXYZINV(end_frame(1:3,1:3));
            P1 = start_frame(1:3,4);

            n = 5;

            for i = 1:n

                Ai = A1 + ( (A2 - A1) * ( i / n ) );
                Pi = P1 + ( P_diff * ( i / n ) );

                Ei = [
                    EULERXYZ(Ai), Pi;
                    0, 0, 0, 1
                ];

                jtControl(Ei, 3, ur5, 0.2);

            end

        case 4
            %temporary square drawing, replace with batman points later

            %ur5InverseDraw(ur5, start_frame, end_frame, 60, 0.66, 5,"bats", [0,0;0,1;1,1;1,0], 30);
            batpoints = batman_points();
            ur5InverseDraw(ur5, start_frame, end_frame, 60, 0.66, 0.5, "bats", batpoints,10);
    end
else
    disp("Transforms would have the marker below the table, risking a collision. Please reset the control program.")
    
end
disp("Drawing complete. Error between expected end pose and actual end pose is shown below.")
%Error calculation
%First get current joints of ur5, create transformation
current_joints = ur5.get_current_joints();
current_transform = ur5FwdKin(current_joints);
error = ur5Error(ur5, current_transform, end_frame);
disp("Error complete. First term of error is the rotational error, second term is the positional error.")
disp(error)