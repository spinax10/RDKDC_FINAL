ur5 = ur5_interface();
%define threshold variable
threshold = 0.005;
%move robot to test start_position
ur5.move_joints([ 1.0386;-1.5330;2.1281;-2.1250;-1.5638;-0.0005],20);
pause(20);
%define test start_frame
start_frame = [0.8618,-0.5066,-0.0268,0.1045;-0.5072,-0.8612,-0.0316,0.4280;-0.0070,0.0409,-0.9991,0.2078;0,0,0,1.0000];
%define test end_frame
end_frame = [0.8621,-0.5060,0.0274,0.2891;-0.5067,-0.8600,0.0607,0.5546;-0.0072,-0.0662,-0.9978,0.2004;0,0,0,1.0000];
%run test function
%place frames first!
FRAME_A = tf_frame("base_link", "start", start_frame)
FRAME_B = tf_frame("base_link", "end", end_frame)
%safety check, noting that the x-direction for this guy is negative
if(ur5MarkerSafetyCheck(start_frame,end_frame,[49,122],0.05) == 1)
testfunc = ur5InverseDraw(ur5, start_frame, end_frame, 60, 0.66, 10, "bats", [0,0;0,1;1,1;1,0], 150);
testfunc-end_frame 
end