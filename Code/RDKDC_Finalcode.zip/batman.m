%% Deelopers: Team RDKDC 
% Batman functions 

float  myArray[] = 