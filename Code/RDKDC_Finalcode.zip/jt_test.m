ur5 = ur5_interface();
ur5.swtich_to_ros_control();
ur5.move_joints(ur5.home(),20);
pause(20);
disp("Move Robot to end position.")
ur5.swtich_to_pendant_control();
w1 = waitforbuttonpress();
endangles = ur5.get_current_joints();
endtransform = ur5FwdKin(endangles);
end_frame = endtransform;
disp("Move robot to start position.")
w2 = waitforbuttonpress();
ur5.swtich_to_ros_control();
startangles = ur5.get_current_joints();
starttransform = ur5FwdKin(startangles);
start_frame = starttransform;


Pa = start_frame(1:3,4) + [(end_frame(1,4) - start_frame(1,4))/3, (end_frame(2,4) - start_frame(2,4))/3,0]';
Pb = Pa + [end_frame(1,4) - start_frame(1,4),end_frame(2,4) - start_frame(2,4),0]';
A1 = EULERXYZINV(start_frame(1:3,1:3));
A2 = EULERXYZINV(end_frame(1:3,1:3));
Aa = A1 + (A2 - A1)/3;
Ab = Aa + (A2 - A1)/3;

Ea = [
  EULERXYZ(Aa),Pa;  
  0,0,0,1
];
Eb = [
  EULERXYZ(Ab),Pb;
  0,0,0,1
];
% jtControl(Ea, 1.5, ur5, 0.3);
% jtControl(Eb, 1.5, ur5, 0.3);
jtControl(end_frame, 1.0 , ur5, 0.2);



